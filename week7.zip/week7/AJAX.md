# Python - Week 7 Day 1 - AJAX  
        
## ******************************************

- Office Hours:  4:00 PM PST
- Lecture:       5:00 PM PST

## ******************************************

## Office Hour

- TBD

## Lecture
    
### Objectives

- understand what an API is and its purpose
- understand JSON objects
- Understand promises
- Use fetch to get data from an API
- Dojo Weather with AJAX

### APIs - Application Programming Interface

- Databases hosted online to access information

### API Key

- Will differ depending on the website

### JSON - Javascript Object Notation

- Universal format for passing data around on the web

### Fetch

- utilizes promises 
- built in web API in javascript used to make requests across the web.

### AJAX - Asynchronous Javascript

- The better solution to promises


